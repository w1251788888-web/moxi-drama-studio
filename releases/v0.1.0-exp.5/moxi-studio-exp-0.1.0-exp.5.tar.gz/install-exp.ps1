# 墨戏生花 · 闭源实验版安装脚本（Windows PowerShell）
# 用法： powershell -ExecutionPolicy Bypass -File .\install-exp.ps1
#        powershell -ExecutionPolicy Bypass -File .\install-exp.ps1 -Profile moxi-exp
param(
  [string]$Profile = 'moxi-exp'
)
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Write-Host "[moxi-exp] profile: $Profile" -ForegroundColor Cyan

if (-not (Get-Command dsh -ErrorAction SilentlyContinue)) {
  Write-Error '缺少 dsh（DeepSeek Harness CLI）。请先安装 DSH，并确认 dsh 在 PATH 中。'
  exit 1
}
$dshHome = if ($env:DSH_HOME) { $env:DSH_HOME } else { Join-Path $env:USERPROFILE '.dsh' }
$profileDir = Join-Path $dshHome "profiles\$Profile"
if (-not (Test-Path $profileDir)) {
  Write-Host '[moxi-exp] 创建 profile（web 模板）' -ForegroundColor Cyan
  dsh --profile $Profile --from-default-profile web --dump-config | Out-Null
}

$tgz = Get-ChildItem (Join-Path $here 'tarballs') -Filter *.tgz | ForEach-Object { $_.FullName }
if (-not $tgz) { Write-Error '找不到 tarballs/*.tgz（请先完整解压压缩包）'; exit 1 }
Write-Host '[moxi-exp] 安装插件包' -ForegroundColor Cyan
& dsh plugin --profile $Profile add @tgz
if ($LASTEXITCODE -ne 0) { Write-Error 'dsh plugin add 失败'; exit 1 }

Write-Host '[moxi-exp] 校验' -ForegroundColor Cyan
$conf = & dsh --profile $Profile --dump-config
foreach ($b in @('moxi-core-bundle', 'moxi-canvas-bundle', 'moxi-admin-bundle')) {
  if ($conf -match [regex]::Escape($b)) { Write-Host "  OK $b" } else { Write-Error "缺少 $b"; exit 1 }
}
# 创建桌面与开始菜单快捷方式（双击启动，不需要记命令）
$launcher = Join-Path $here 'start-moxi.cmd'
$icon = Join-Path $here 'Moxi.ico'
try {
  $ws = New-Object -ComObject WScript.Shell
  $targets = @(
    (Join-Path ([Environment]::GetFolderPath('Desktop')) '墨戏生花.lnk'),
    (Join-Path ([Environment]::GetFolderPath('Programs')) '墨戏生花.lnk')
  )
  foreach ($lnkPath in $targets) {
    $sc = $ws.CreateShortcut($lnkPath)
    $sc.TargetPath = $launcher
    $sc.WorkingDirectory = $here
    $sc.WindowStyle = 1
    $sc.Description = '墨戏生花 · 短剧创作工作台'
    if (Test-Path $icon) { $sc.IconLocation = $icon }
    $sc.Save()
  }
  Write-Host '[moxi-exp] 已在桌面和开始菜单创建「墨戏生花」快捷方式' -ForegroundColor Green
} catch {
  Write-Warning "创建快捷方式失败（可手动双击 start-moxi.cmd）：$($_.Exception.Message)"
}

Write-Host "[moxi-exp] 完成。以后双击桌面「墨戏生花」即可打开。" -ForegroundColor Green
Write-Host "[moxi-exp] 命令行启动： dsh --profile $Profile"
Write-Host "[moxi-exp] 数据目录： $env:USERPROFILE\Documents\Moxi\projects"
