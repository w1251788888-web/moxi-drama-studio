@echo off
chcp 65001 >nul
setlocal
set PROFILE=moxi-exp
title 墨戏生花
where dsh >nul 2>nul
if errorlevel 1 (
  echo.
  echo [墨戏生花] 未找到 dsh（DeepSeek Harness CLI）。
  echo 请先安装 DeepSeek Harness，并确认在命令行里输入 dsh 能运行。
  echo 装好后重新双击本文件。
  echo.
  pause
  exit /b 1
)
echo [墨戏生花] 正在启动本地服务（首次约 15 秒）…
echo 浏览器会自动打开；本窗口不要关，关掉即停止服务。
echo.
dsh --profile %PROFILE%
echo.
echo [墨戏生花] 服务已结束。
pause
