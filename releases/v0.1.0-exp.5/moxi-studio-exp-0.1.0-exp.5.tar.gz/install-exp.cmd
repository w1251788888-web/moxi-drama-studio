@echo off
REM 墨戏生花 · 闭源实验版安装（双击运行）
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-exp.ps1" %*
if errorlevel 1 (
  echo.
  echo 安装失败，请把上面的错误信息发给提供者。
  pause
  exit /b 1
)
echo.
echo 安装完成。启动命令：dsh --profile moxi-exp
pause
