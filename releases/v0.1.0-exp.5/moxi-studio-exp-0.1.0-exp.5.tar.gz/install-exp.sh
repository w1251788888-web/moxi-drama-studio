#!/usr/bin/env bash
# 墨戏生花 · 闭源实验版安装脚本
# 用法：bash install-exp.sh          # 默认 profile: moxi-exp
#       MOXI_PROFILE=moxi bash install-exp.sh
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROFILE="${MOXI_PROFILE:-moxi-exp}"
say() { printf '\033[1;36m[moxi-exp]\033[0m %s\n' "$*"; }
command -v dsh >/dev/null || { echo "缺少 dsh（DeepSeek Harness CLI）"; exit 1; }

say "profile: $PROFILE"
if [ ! -d "${DSH_HOME:-$HOME/.dsh}/profiles/$PROFILE" ]; then
  say "创建 profile（web 模板）"
  dsh --profile "$PROFILE" --from-default-profile web --dump-config >/dev/null
fi

TGZ="$HERE/tarballs"
PKGS=$(ls "$TGZ"/*.tgz)
say "安装插件包"
dsh plugin --profile "$PROFILE" add $PKGS

say "校验"
for b in moxi-core-bundle moxi-canvas-bundle moxi-admin-bundle; do
  dsh --profile "$PROFILE" --dump-config | grep -q "$b" || { echo "✗ $b 未挂载"; exit 1; }
  echo "  ✓ $b"
done
say "完成。启动：dsh --profile $PROFILE"
say "数据目录：${MOXI_PROJECTS_ROOT:-$HOME/Documents/Moxi/projects}"
