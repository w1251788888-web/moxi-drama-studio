/* moxi-admin-bundle @ 0.1.0-exp.5 — host stub（无 Host 行为） */
export const name = "moxi-admin"
export function apply() {}
