@echo off
chcp 65001 >nul
setlocal
set OUT=%USERPROFILE%Desktopmoxi-diagnose.txt
echo 墨戏生花排障报告 > "%OUT%"
echo 生成时间: %DATE% %TIME% >> "%OUT%"
echo ===== >> "%OUT%"
echo [dsh] >> "%OUT%"
where dsh >> "%OUT%" 2>&1
dsh --version >> "%OUT%" 2>&1
echo ===== >> "%OUT%"
echo [profiles] >> "%OUT%"
dsh --profile moxi-exp --dump-config 2>&1 | findstr /C:"moxi-core" /C:"moxi-canvas" /C:"moxi-admin" /C:"error" >> "%OUT%"
echo ===== >> "%OUT%"
echo [node] >> "%OUT%"
where node >> "%OUT%" 2>&1
node --version >> "%OUT%" 2>&1
echo ===== >> "%OUT%"
echo [python] >> "%OUT%"
where python >> "%OUT%" 2>&1
where py >> "%OUT%" 2>&1
echo ===== >> "%OUT%"
echo [dir] >> "%OUT%"
dir "%~dp0" >> "%OUT%" 2>&1
echo.
echo 报告已写到桌面：moxi-diagnose.txt
echo 把它发给提供者即可定位问题。
pause
