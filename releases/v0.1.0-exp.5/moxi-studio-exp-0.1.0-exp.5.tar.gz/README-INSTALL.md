# 墨戏生花 · DeepSeek 插件（闭源实验版 v0.1.0-exp.5）

> 实验版：功能可用但不保证稳定，可能变更或改数据。建议先备份 `~/Documents/Moxi/projects`。

## 安装

### Windows（PowerShell，推荐）

```powershell
Expand-Archive moxi-studio-exp-0.1.0-exp.5.tar.gz -DestinationPath .
cd moxi-studio-exp-0.1.0-exp.5
powershell -ExecutionPolicy Bypass -File .install-exp.ps1
```

或解压后双击 `install-exp.cmd`。

### macOS / Linux

```bash
tar xzf moxi-studio-exp-0.1.0-exp.5.tar.gz
cd moxi-studio-exp-0.1.0-exp.5
bash install-exp.sh
```

> profile 默认 `moxi-exp`；macOS/Linux 可用 `MOXI_PROFILE=xxx`、Windows 可用 `-Profile xxx` 改名。

安装脚本会：
1. 用 DSH 的 web 模板创建/复用 profile（默认 `moxi-exp`）
2. 把三个插件包装进该 profile（本地 tarball 安装，不联网）
3. 校验三个 bundle 已挂载，并打印启动命令

## 启动

```bash
dsh --profile moxi-exp
```

首次启动会打印带 token 的地址；左侧栏出现「墨戏画布」「墨戏后台」。
生成需要 DeepSeek API 密钥（在 profile 的 `cordis.patch.yml` 中配置 `llm-deepseek-*`，或沿用本机已登录的 DSH 账户）。

## 使用

1. 墨戏画布 → 新开一部剧（填剧名/集数/受众/题材/一句话故事）
2. 点「⚡ 生成」→ 选起止集 → 进度抽屉实时看；可取消/续跑
3. 生成完点「可拍性」→ 看逐集时长/角色/钩子，逐集签收
4. 满意后点「人工放行」→「导出」docx

## 卸载

```bash
dsh plugin --profile moxi-exp remove moxi-core-bundle moxi-canvas-bundle moxi-admin-bundle
```
项目数据不会被删除：`~/Documents/Moxi/projects`（可用 `MOXI_PROJECTS_ROOT` 改）。

## 授权

闭源专有软件，仅限被授权方本机使用，禁止再分发/反编译。详见 LICENSE.txt。
